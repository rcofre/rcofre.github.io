---
title: "Novel perspectives on the structure-function dynamics of the primate and human brain under diverse consciousness states"
collection: talks
type: "Seminar"
permalink: /talks/2023-structure-function-consciousness-strasbourg/
venue: "Université de Strasbourg"
date: 2023-06-01
location: "Strasbourg, France"
---

[Watch here](https://www.youtube.com/watch?v=QnWoPyu7yuI&t=1662s&ab_channel=Funsy-Seminars)

Summary: The analysis of brain network dynamics provides an insightful perspective to analyze the dynamic reconfiguration in brain network structure across species to investigate its role during the loss of consciousness. Recent work has highlighted the importance of the dynamical aspect in understanding the functional relevance of alterations in this network structure to investigate how the brain supports consciousness. In this talk, my idea is to fly over a set of ideas and recent results in order to discuss the problems associated with data analysis in the temporal dimension. I will show convergent and complementary results between different methods of investigating the dynamical aspects of the structure-function relationship during the loss of consciousness in the primate and human brain.
