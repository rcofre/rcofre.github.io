---
title: "Whole-Brain Models"
collection: talks
type: "Mini-course"
permalink: /talks/2021-whole-brain-models-inria/
redirect_from:
  - /talks/2012-03-01-talk-1/
venue: "Inria Sophia-Antipolis"
date: 2021-10-20
location: "Nice, France"
---

[Watch here](https://pod.univ-cotedazur.fr/video/12323-mini-course-rodrigo-cofre-whole-brain-models_part1/)

Summary: Human neuroscience research has been increasingly dominated by imaging experiments, that are usually insufficient to inform about the underlying mechanisms at play behind the observed neural phenomena unfolding at different spatial and temporal scales. In addition, since ethical considerations severely limit direct causal manipulation of human brain activity, most of the neuroimaging literature is limited to correlational studies. An important complement to this research is provided by Whole-Brain Models.

In the first part of this course, I will introduce the idea of Whole-brain modeling with the purpose of making causal and mechanistic hypotheses about the observed brain activity. I will introduce the basics of Whole-brain modeling, namely local dynamical systems coupled by large-scale anatomical connectivity networks, fitted to reproduce statistical measures of brain activity.

In the second part of this course, I will show examples of applications of Whole-brain modeling and argue that this approach provides a practical, ethical, and inexpensive "digital scalpel", which allows researchers to explore the counterfactual consequences of modifying structural or dynamical aspects of the brain. I will show that Whole-Brain Models represent a valuable tool to narrow the space of mechanistic explanations compatible with the observed neuroimaging data, including data acquired from subjects undergoing different brain states induced by pharmacological interventions, pathological conditions, aging, etc.
